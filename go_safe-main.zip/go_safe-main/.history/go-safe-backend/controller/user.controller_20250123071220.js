const UserServices = require("../services/user.services");

exports.signup = async (req, res, next) => {
  try {
    const { email, phoneNumber, password, name } = req.body;
    const successRes = await UserServices.signupUser(
      email,
      phoneNumber,
      password,
      name
    );

    if (successRes) {
      res.status(200).json({ message: "Account created" });
    } else {
      res.status(400).json({ message: "Failed to create account" });
    }
  } catch (error) {
    console.log("Error ocurred while creating user: " + error);
    next(error);
  }
};

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await UserServices.
  } catch (error) {
    console.log("Error ocurred during login: "+error);
  }
};
