const express = require("express");
const body_parser = require("body-parser");
const userRouter = require("./router/user.route");

const app = express();

module.exports = app;
