const UserModel = require("../model/user.model");

class UserServices {
  //* For signup
  static async signupUser(email, phoneNumber, password, name) {}
}
