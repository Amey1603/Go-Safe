const mongoose = require("mongoose");
const db = require("../config/db");
const { Schema } = mongoose;

const userSchema = new Schema({
  email: {
    type: String,
    unique: true,
    required: true,
  },
  phoneNumber: {
    type: String,
    unique: true,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  profilePicture: {
    type: String,
    default: null,
  },
});

const UserSchema = db.model("users", userSchema);

module.exports = UserSchema;
