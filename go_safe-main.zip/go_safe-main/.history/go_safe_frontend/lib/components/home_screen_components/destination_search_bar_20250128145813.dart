import 'package:flutter/cupertino.dart';

class DestinationSearchBar extends StatelessWidget implements PreferredSizeWidget {
  const DestinationSearchBar({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => throw UnimplementedError();
}
