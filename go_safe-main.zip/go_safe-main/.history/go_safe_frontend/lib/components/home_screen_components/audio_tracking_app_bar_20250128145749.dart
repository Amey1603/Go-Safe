import 'package:flutter/cupertino.dart';

class AudioTrackingAppBar extends StatelessWidget implements PreferredSizeWidget {
  const AudioTrackingAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => throw UnimplementedError();
}
