import 'package:flutter/cupertino.dart';

class NavigationInfoWindow extends StatefulWidget {
  const NavigationInfoWindow({super.key});

  @override
  State<NavigationInfoWindow> createState() => _NavigationInfoWindowState();
}

class _NavigationInfoWindowState extends State<NavigationInfoWindow> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
