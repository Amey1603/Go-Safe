import 'package:flutter/material.dart';

class SOSAppBar extends StatelessWidget implements AppBar {
  const SOSAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
