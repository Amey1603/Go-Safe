import 'package:flutter/material.dart';

class SOSAppBar extends StatelessWidget {
  const SOSAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
